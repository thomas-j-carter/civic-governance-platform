# Ardtire Governance Platform — Repo Snapshot

This archive is a high-fidelity continuation snapshot for the Ardtire digital governance platform.

## Important
This is **not** a byte-for-byte export of the full original working repo. The chat session did not contain a fully materialized source tree to package directly.

What this snapshot **does** include:

- canonical AI context bundle
- prompts and system rules
- automation scaffolding
- handoff/bootstrap materials
- repo structure for `apps/gov-api`
- placeholder `prisma/schema.prisma`
- placeholder `apps/gov-api/openapi.yaml`
- starter package scripts
- validator/context compiler tooling

Use this as the transfer bundle to rehydrate work on another machine and continue from a fresh chat using `BOOTSTRAP_PROMPT.md`.
